package br.com.fiap.dao;

import br.com.fiap.agenda.Contato;
/**
 * Classe de manipulacao de objetos persistidos via JPA
 * Objetos da classe bean Contato
 */
public class ContatoDAO extends GenericDAO<Contato> {

}
